from django.conf import settings
from django.conf.urls import include, url
from django.contrib import admin
from django.conf.urls.static import static
from app import views, apis
from django.urls import reverse

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^predict/$', views.index, name='index'),
    url(r'^api/client/get/result/(?P<Gender>\d+)/(?P<Age>\d+)/(?P<Height>\d+)/(?P<Weight>\d+)/(?P<family_history_with_overweight>\d+)/(?P<FAVC>\d+)/(?P<FCVC>\d+)/(?P<NCP>\d+)/(?P<CAEC>\d+)/(?P<SMOKE>\d+)/(?P<CH2O>\d+)/(?P<SCC>\d+)/(?P<FAF>\d+)/(?P<TUE>\d+)/(?P<CALC>\d+)/(?P<MTRANS>\d+)/$', apis.client_get_result),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)